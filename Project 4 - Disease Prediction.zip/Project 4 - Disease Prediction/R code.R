getwd()
setwd("D:/Disease Predection/Disease Prediction Project/Project 4 - Disease Prediction")
disease
disease <- read.csv("CancerData.csv", na.strings = c(""," ","NA"))
disease<-disease[!duplicated(disease),]
library(Amelia)
missmap(disease)
sapply(disease,function(x) sum(is.na(x)))
x=na.omit(disease)
disease<-disease[!names(disease) %in% c("X")]
disease
prop.table(table(disease$diagnosis))
is_outlier <- function(x) {
  return(x < quantile(x, 0.25) - 1.5 * IQR(x) | x > quantile(x, 0.75) + 1.5 * IQR(x))
}
is_outlier
dput(colnames(disease))
meanvar=c( "radius_mean", "texture_mean", "perimeter_mean", 
           "area_mean", "smoothness_mean", "compactness_mean", "concavity_mean", 
           "concave.points_mean", "symmetry_mean", "fractal_dimension_mean")
library(corrplot)

corrplot(cor(disease[,names(disease)%in% meanvar]),type="full",order="hclust",tl.cex = 1,tl.col = "Black",addrect = 8,method = "circle")
dput(colnames(disease))
SEvar=c( "radius_se", "texture_se", "perimeter_se", "area_se", "smoothness_se", 
         "compactness_se", "concavity_se", "concave.points_se", "symmetry_se",
 "fractal_dimension_se")
library(corrplot)

corrplot(cor(disease[,names(disease)%in% SEvar]),type="full",order="hclust",tl.cex = 1,tl.col = "Black",addrect = 8,method = "circle")
worsevar=c(  "radius_worst", "texture_worst", "perimeter_worst", 
             "area_worst", "smoothness_worst", "compactness_worst", "concavity_worst", 
             "concave.points_worst", "symmetry_worst", "fractal_dimension_worst")
library(corrplot)

corrplot(cor(disease[,names(disease)%in% worsevar]),type="full",order="AOE",tl.cex = 1,tl.col = "Black",addrect = 8,method = "color",addCoef.col = "gray")
library("caret")
library("dplyr")
#Remove Highly correlated 
disease1=disease %>% select(-findCorrelation(cor(disease %>% select(-id,-diagnosis)),cutoff=.8))
disease1

library("caret")
set.seed(123)
df3=cbind(diagnosis=disease$diagnosis,disease1)
index<-createDataPartition(df3$diagnosis,times = 1,p = .9,list=FALSE)
training=df3[index,]
testing=df3[-index,]
library("caret")
dfcontrol<-trainControl(method = "cv",number=10,classProbs = TRUE)
logit <- train(diagnosis ~ .,data=training,method="glm",metric="ROC",preProcess=c("scale","center"),trControl=dfcontrol)
dput(colnames(df3))
logit_pred<-predict(logit,testing)
cm<-confusionMatrix(logit_pred,testing$diagnosis,positive = "M")
cm

#Random Forest
library("rpart")
library("caret")
set.seed(1234)
df3=cbind(diagnosis=disease$diagnosis,disease1)
index<-createDataPartition(df3$diagnosis,times = 1,p = .9,list=FALSE)
training=df3[index,]
testing=df3[-index,]
library("caret")
model_dt=train(diagnosis ~ .,data=training,method="rf")
model_dt_1 = predict(model_dt, data = training)
cm<-confusionMatrix(model_dt_1,testing$diagnosis,positive = "M")
cm
